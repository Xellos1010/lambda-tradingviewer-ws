"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StrategyDocument = void 0;
const dynamoose = __importStar(require("dynamoose"));
const Item_1 = require("dynamoose/dist/Item");
const config_1 = __importDefault(require("../../config"));
class StrategyDocument extends Item_1.Item {
}
exports.StrategyDocument = StrategyDocument;
const StrategySchema = new dynamoose.Schema({
    id: {
        type: String,
        hashKey: true,
    },
    type: {
        type: String,
        index: {
            name: 'typeIndex',
        },
    },
    symbol: {
        type: String,
        index: {
            name: 'symbolIndex',
        },
    },
    status: {
        type: String,
        index: {
            name: 'statusIndex',
        },
    },
    profit: Number,
    data: String,
    createdAt: Date,
    holdId: {
        type: String,
        index: {
            name: 'holdIdIndex',
        },
    },
    unHoldPrice: Number,
});
exports.default = dynamoose.model(config_1.default.tables.strategy, StrategySchema, {
    saveUnknown: false
});
//# sourceMappingURL=strategy.js.map