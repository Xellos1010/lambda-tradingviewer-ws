import { Item } from "dynamoose/dist/Item";
export declare class StrategyDocument extends Item {
    id?: string;
    type?: string;
    symbol?: string;
    status?: string;
    profit?: number;
    data?: string;
    createdAt?: Date;
    holdId?: string;
    unHoldPrice?: number;
}
declare const _default: import("dynamoose/dist/General").ModelType<StrategyDocument>;
export default _default;
//# sourceMappingURL=strategy.d.ts.map