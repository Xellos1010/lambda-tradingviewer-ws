import { Item } from 'dynamoose/dist/Item';
export declare class SettingDocument extends Item {
    id?: string;
    type?: string;
    symbol?: string;
    status?: string;
    data?: string;
    createdAt?: Date;
}
declare const _default: import("dynamoose/dist/General").ModelType<SettingDocument>;
export default _default;
//# sourceMappingURL=setting.d.ts.map