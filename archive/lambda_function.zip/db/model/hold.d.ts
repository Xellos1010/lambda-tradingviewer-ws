import { Item } from "dynamoose/dist/Item";
export declare class HoldDocument extends Item {
    id?: string;
    type?: string;
    symbol?: string;
    status?: string;
    data?: string;
    avgPrice?: number;
    avgPriceProfit?: number;
    orderId?: string;
    qty?: number;
    createdAt?: Date;
}
declare const _default: import("dynamoose/dist/General").ModelType<HoldDocument>;
export default _default;
//# sourceMappingURL=hold.d.ts.map