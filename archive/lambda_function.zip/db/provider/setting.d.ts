import { SettingDocument } from '../model/setting';
import Base from './base';
declare class Setting extends Base<SettingDocument, TSetting> {
    getByTypeAndSymbol(type: string, symbol: string): Promise<TSetting>;
}
declare const _default: Setting;
export default _default;
//# sourceMappingURL=setting.d.ts.map