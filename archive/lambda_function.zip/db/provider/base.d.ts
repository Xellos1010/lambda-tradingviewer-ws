import { AnyItem } from "dynamoose/dist/Item";
import { Model } from "dynamoose/dist/Model";
import { Condition, ConditionInitializer } from "dynamoose/dist/Condition";
export default class BaseProvider<BaseDocument extends AnyItem, Data extends {
    data?: string | object;
    id?: string;
    createdAt?: string | number;
    user?: string;
}> {
    model: Model;
    user: string;
    constructor(model: Model<BaseDocument>);
    addUserToFilter(filter: Partial<Data> | ConditionInitializer): Condition | {
        user: string;
        constructor: Function;
        toString(): string;
        toLocaleString(): string;
        valueOf(): Object;
        hasOwnProperty(v: PropertyKey): boolean;
        isPrototypeOf(v: Object): boolean;
        propertyIsEnumerable(v: PropertyKey): boolean;
    };
    count(filter: Partial<Data> | ConditionInitializer): Promise<number>;
    getList(filter: Partial<Data> | ConditionInitializer, options?: {
        limit?: number;
        order?: "descending" | "ascending";
    }): Promise<Data[]>;
    getFirst(filter: Partial<Data>): Promise<Data | undefined>;
    dataFromDB(model: Data): Data;
    dataToDB(model: Data): Data;
    create(data: Data): Promise<Data>;
    update({ id, ...data }: Data): Promise<Data>;
    removeFields(id: string | undefined, fieldList: string[]): Promise<void>;
    getRandomId(): string;
    getNowUnix(): number;
    deleteById(id: string | undefined): Promise<void>;
    getById(id: string | undefined): Promise<Data | undefined>;
}
//# sourceMappingURL=base.d.ts.map