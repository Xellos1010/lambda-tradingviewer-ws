"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const uuid_1 = require("uuid");
const Condition_1 = require("dynamoose/dist/Condition");
const config_1 = __importDefault(require("../../config"));
class BaseProvider {
    constructor(model) {
        this.model = model;
        this.user = config_1.default.user.email;
    }
    addUserToFilter(filter) {
        console.log("Input filter:", filter);
        if (filter instanceof Condition_1.Condition) {
            return filter;
        }
        const resultFilter = { ...filter, user: this.user };
        console.log("Result filter:", resultFilter);
        return resultFilter;
    }
    async count(filter) {
        const res = await this.model
            .query(filter)
            .count()
            .exec();
        return res.count;
    }
    async getList(filter, options = {}) {
        const { limit, order } = options;
        let query = this.model.query(filter);
        if (order) {
            query.filter("createdAt").ge(+new Date() - 365 * 24 * 60 * 60 * 1000);
            query.sort(order);
        }
        if (limit) {
            query.limit(limit);
        }
        console.log("Filter:", filter);
        const result = await query.exec();
        console.log("Result:", result);
        return result.toJSON().map((m) => this.dataFromDB(m));
    }
    async getFirst(filter) {
        const resultList = await this.getList(filter, { limit: 1 });
        console.log('Result list:', resultList);
        return resultList[0];
    }
    dataFromDB(model) {
        if (model?.data && typeof model?.data === "string") {
            try {
                model.data = JSON.parse(model.data);
            }
            catch (e) {
                console.error("Parse data error", e);
            }
        }
        return model;
    }
    dataToDB(model) {
        if (model.data && typeof model.data === "object") {
            try {
                model.data = JSON.stringify(model.data);
            }
            catch (e) {
                console.error("Stringify data error", e);
            }
        }
        if (model?.createdAt && typeof model?.createdAt === "string") {
            model.createdAt = Number(new Date(model.createdAt));
        }
        return model;
    }
    async create(data) {
        const d = {
            id: this.getRandomId(),
            createdAt: this.getNowUnix(),
            user: this.user,
            ...this.dataToDB(data),
        };
        const s = (await this.model.create(d));
        return this.dataFromDB(s.toJSON());
    }
    async update({ id, ...data }) {
        await this.model.update(id, this.dataToDB(data));
        return { id, ...data };
    }
    async removeFields(id, fieldList) {
        if (id) {
            await this.model.update(id, { $REMOVE: fieldList });
        }
    }
    getRandomId() {
        return (0, uuid_1.v4)();
    }
    getNowUnix() {
        return parseInt(String(+new Date()));
    }
    async deleteById(id) {
        if (id) {
            const el = await this.getById(id);
            if (el && el?.user === this.user) {
                return this.model.delete(id);
            }
        }
    }
    async getById(id) {
        if (!id) {
            return undefined;
        }
        const res = await this.model.get(id);
        if (!res) {
            return undefined;
        }
        return this.dataFromDB(res.toJSON());
    }
}
exports.default = BaseProvider;
//# sourceMappingURL=base.js.map