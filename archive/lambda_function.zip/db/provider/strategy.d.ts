import { StrategyDocument } from '../model/strategy';
import Base from './base';
declare class Strategy extends Base<StrategyDocument, TStrategy> {
    getByTypeAndSymbol(type: string, symbol: string): Promise<TStrategy[]>;
    create(data: TStrategy): Promise<TStrategy>;
    update(s: TStrategy): Promise<TStrategy>;
    getByHoldId(type: string, symbol: string, holdId: string): Promise<TStrategy[]>;
    getSimilarHold(strategy: TStrategy, currentPrice: number): Promise<TStrategy | undefined>;
    getByTypeAndSymbolStatus(type: string, symbol: string, status: string): Promise<TStrategy[]>;
    getCurrentStrategy(type: string, symbol: string): Promise<TStrategy | undefined>;
    calculateProfit(type: string, symbol: string): Promise<number>;
}
declare const _default: Strategy;
export default _default;
//# sourceMappingURL=strategy.d.ts.map