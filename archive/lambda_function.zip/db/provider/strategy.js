"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const strategy_1 = __importDefault(require("../model/strategy"));
const base_1 = __importDefault(require("./base"));
const constants_1 = require("../../constants");
const order_1 = require("../../helper/order");
const dynamoose = __importStar(require("dynamoose"));
class Strategy extends base_1.default {
    getByTypeAndSymbol(type, symbol) {
        return this.getList({ type, symbol });
    }
    create(data) {
        return super.create({
            status: constants_1.STRATEGY_STATUS.CREATED,
            ...data
        });
    }
    update(s) {
        if (s.id) {
            return super.update(s);
        }
        else {
            return this.create(s);
        }
    }
    getByHoldId(type, symbol, holdId) {
        return this.getList({ type, symbol, holdId });
    }
    async getSimilarHold(strategy, currentPrice) {
        const list = (await this.getList({
            type: strategy.type,
            symbol: strategy.symbol,
            status: constants_1.STRATEGY_STATUS.HOLD,
        })) || [];
        return list.find((s) => currentPrice >= (0, order_1.getOrderPrice)(s.data?.buyOrder));
    }
    getByTypeAndSymbolStatus(type, symbol, status) {
        return this.getList({ type, symbol, status });
    }
    getCurrentStrategy(type, symbol) {
        return this.getFirst({ type, symbol, status: constants_1.STRATEGY_STATUS.STARTED });
    }
    async calculateProfit(type, symbol) {
        const condition = new dynamoose
            .Condition()
            .filter('user').eq(this.user)
            .filter('type').eq(type)
            .filter('symbol').eq(symbol)
            .filter('status').in([constants_1.STRATEGY_STATUS.FINISHED, constants_1.STRATEGY_STATUS.UNHOLD]);
        const strategies = await this.getList(condition);
        return strategies.reduce((acc, el) => acc + (Number(el.profit) || 0), 0);
    }
}
exports.default = new Strategy(strategy_1.default);
//# sourceMappingURL=strategy.js.map