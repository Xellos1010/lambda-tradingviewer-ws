"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const hold_1 = __importDefault(require("../model/hold"));
const base_1 = __importDefault(require("./base"));
const constants_1 = require("../../constants");
class Hold extends base_1.default {
    getByTypeAndSymbol(type, symbol) {
        return this.getFirst({ type, symbol });
    }
    getByTypeAndSymbolStatus(type, symbol, status) {
        return this.getFirst({ type, symbol, status });
    }
    create(data) {
        return super.create({
            status: constants_1.HOLD_STATUS.STARTED,
            ...data
        });
    }
    getCurrentHolds() {
        return this.getList({ status: constants_1.HOLD_STATUS.STARTED });
    }
}
exports.default = new Hold(hold_1.default);
//# sourceMappingURL=hold.js.map