import { HoldDocument } from '../model/hold';
import Base from './base';
declare class Hold extends Base<HoldDocument, THold> {
    getByTypeAndSymbol(type: string, symbol: string): Promise<THold | undefined>;
    getByTypeAndSymbolStatus(type: string, symbol: string, status: string): Promise<THold | undefined>;
    create(data: THold): Promise<THold>;
    getCurrentHolds(): Promise<THold[]>;
}
declare const _default: Hold;
export default _default;
//# sourceMappingURL=hold.d.ts.map