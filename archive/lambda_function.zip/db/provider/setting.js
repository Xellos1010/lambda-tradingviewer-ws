"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const setting_1 = __importDefault(require("../model/setting"));
const base_1 = __importDefault(require("./base"));
const config_1 = __importDefault(require("../../config"));
class Setting extends base_1.default {
    async getByTypeAndSymbol(type, symbol) {
        let setting = await this.getFirst({ type, symbol });
        if (!setting) {
            setting = await this.create({
                type,
                symbol,
                data: config_1.default.strategy.defaultSetting
            });
        }
        return setting;
    }
}
exports.default = new Setting(setting_1.default);
//# sourceMappingURL=setting.js.map