declare const _default: {
    tables: {
        hold: string;
        setting: string;
        strategy: string;
    };
    binance: {
        key: string;
        secret: string;
    };
    coinbase: {
        key: string;
        secret: string;
        passphrase: string;
    };
    strategy: {
        type: string;
        asset: string;
        currency: string;
        defaultSetting: {
            isReuseHold: boolean;
            riskPercent: number;
            minAmountUSD: number;
        };
    };
    user: {
        email: string;
    };
    cognito: {
        userPoolId: string | undefined;
        clientId: string | undefined;
        region: string | undefined;
    };
};
export default _default;
//# sourceMappingURL=index.d.ts.map