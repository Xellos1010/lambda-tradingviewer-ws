"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
console.log(process.env.DYNAMODB_HOLD_TABLE);
console.log(process.env.DYNAMODB_SETTING_TABLE);
console.log(process.env.DYNAMODB_STRATEGY_TABLE);
exports.default = {
    tables: {
        hold: process.env.DYNAMODB_HOLD_TABLE,
        setting: process.env.DYNAMODB_SETTING_TABLE,
        strategy: process.env.DYNAMODB_STRATEGY_TABLE,
    },
    binance: {
        key: process.env.BINANCE_API_KEY,
        secret: process.env.BINANCE_API_SECRET
    },
    coinbase: {
        key: process.env.COINBASE_API_KEY,
        secret: process.env.COINBASE_API_SECRET,
        passphrase: process.env.COINBASE_API_PASSPHRASE
    },
    strategy: {
        type: 'most',
        asset: 'BTC',
        currency: 'USD',
        defaultSetting: { isReuseHold: true, riskPercent: 0.05, minAmountUSD: 11 }
    },
    user: {
        email: 'admin@admin.com'
    },
    cognito: {
        userPoolId: process.env.AWS_COGNITO_USER_POOL_ID,
        clientId: process.env.AWS_COGNITO_APP_CLIENT_ID,
        region: process.env.AWS_COGNITO_REGION,
    }
};
//# sourceMappingURL=index.js.map