export {};
//# sourceMappingURL=test-baseapi-spot-service.d.ts.map