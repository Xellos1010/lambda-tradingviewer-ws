export declare const handler: () => Promise<{
    success: boolean;
    statusCode: number;
}>;
//# sourceMappingURL=cron.d.ts.map