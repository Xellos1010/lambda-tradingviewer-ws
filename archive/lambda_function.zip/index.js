"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = exports.successResponse = exports.errorResponse = void 0;
const constants_1 = require("./constants");
const config_1 = __importDefault(require("./config"));
const SpotStrategy_1 = __importDefault(require("./strategy/SpotStrategy"));
const cognito_1 = __importDefault(require("./helper/cognito"));
const getAction = (action) => {
    return action;
};
const signalSpotProcessing = async (action, symbol, currency, type, accessToken) => {
    try {
        const strategy = new SpotStrategy_1.default(symbol, type);
        await strategy.init();
        if (action === constants_1.STRATEGY_ACTION_SELL) {
            await strategy.sell();
        }
        else if (action === constants_1.STRATEGY_ACTION_BUY) {
            try {
                await strategy.buy(currency);
            }
            catch (e) {
                console.log('error buy', e);
            }
        }
        else if (action === constants_1.BOT_STAT) {
            await getCognitoUser(accessToken);
            return strategy.stat();
        }
    }
    catch (e) {
        console.error('signalSpotProcessing error', e);
    }
};
const getAccessToken = (req) => {
    return req.headers?.authorization || "";
};
const getCognitoUser = async (accessToken) => {
    if (accessToken) {
        const cognitoUser = await cognito_1.default.getUserByAccessToken(accessToken);
        if (cognitoUser && cognitoUser.email && cognitoUser.email === config_1.default.user.email) {
            return cognitoUser;
        }
    }
    throw new Error('Unauthorized');
};
const errorResponse = (statusCode, message) => {
    return {
        statusCode,
        body: JSON.stringify({
            status: "error",
            message,
        }),
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        },
    };
};
exports.errorResponse = errorResponse;
const successResponse = () => {
    return {
        statusCode: 200,
        body: JSON.stringify({
            status: "success",
            message: "Signal Processed",
        }),
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "OPTIONS,POST",
            "Access-Control-Allow-Headers": "Content-Type",
        },
    };
};
exports.successResponse = successResponse;
const parseBody = (str) => {
    const result = {};
    let key = '';
    let value = '';
    let insideParentheses = false;
    for (let i = 0; i < str.length; i++) {
        const char = str[i];
        if (char === '(')
            insideParentheses = true;
        if (char === ')')
            insideParentheses = false;
        if (char === ',' && !insideParentheses) {
            result[key.trim()] = value.trim();
            key = '';
            value = '';
        }
        else if (char === ':' && key === '') {
            key = value;
            value = '';
        }
        else {
            value += char;
        }
    }
    if (key !== '') {
        result[key.trim()] = value.trim();
    }
    return {
        strategy_name: result.strategy_name,
        strategy_params: result.strategy_params,
        order_action: result.order_action,
        contracts: result.contracts,
        ticker: result.ticker,
        position_size: result.position_size,
    };
};
const handler = async (event, _) => {
    console.log("Received event:", JSON.stringify(event, null, 2));
    if (event.body === null) {
        console.log("Body is null");
        return (0, exports.errorResponse)(400, "Missing body");
    }
    const bodyStr = event.body;
    let body = parseBody(bodyStr);
    console.log("Parsed body:", body);
    const strategyName = body.strategy_name;
    console.log("Strategy Name:", strategyName);
    const strategyParams = body.strategy_params;
    console.log("Strategy Params:", strategyParams);
    const orderAction = body.order_action;
    console.log("Order Action:", orderAction);
    const contracts = body.contracts;
    console.log("Contracts:", contracts);
    const ticker = body.ticker;
    console.log("Ticker:", ticker);
    const positionSize = body.position_size;
    console.log("Position Size:", positionSize);
    const action = getAction(orderAction);
    const accessToken = getAccessToken(event);
    const asset = config_1.default.strategy.asset;
    const currency = config_1.default.strategy.currency;
    const symbol = `${asset}-${currency}`;
    const type = config_1.default.strategy.type;
    try {
        body = await signalSpotProcessing(action, symbol, currency, type, accessToken);
    }
    catch (e) {
        console.log('error', e);
    }
    return (0, exports.successResponse)();
};
exports.handler = handler;
//# sourceMappingURL=index.js.map