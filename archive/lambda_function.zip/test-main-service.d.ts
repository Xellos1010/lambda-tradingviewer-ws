/// <reference path="../src/types/global.d.ts" />
export declare const handler: any;
//# sourceMappingURL=test-main-service.d.ts.map