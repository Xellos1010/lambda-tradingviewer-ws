export declare const ORDER: {
    MIN_USD: number;
    EXECUTION_TYPE: {
        CANCELED: string;
        NEW: string;
        TRADE: string;
    };
    TYPE: {
        LIMIT: string;
        MARKET: string;
        STOP: string;
        OCO: string;
        STOP_MARKET: string;
        TAKE_PROFIT: string;
        LIMIT_MAKER: string;
        STOP_LOSS_LIMIT: string;
        TAKE_PROFIT_MARKET: string;
        TRAILING_STOP_MARKET: string;
    };
    STATUS: {
        NEW: string;
        PARTIALLY_FILLED: string;
        FILLED: string;
        CANCELED: string;
        PENDING_CANCEL: string;
        REJECTED: string;
        EXPIRED: string;
    };
    SIDE: {
        BUY: string;
        SELL: string;
    };
    SIDE_DUAL: {
        LONG: string;
        SHORT: string;
        BOTH: string;
    };
    TIME_IN_FORCE: {
        GTC: string;
        IOC: string;
        FOK: string;
        GTX: string;
    };
    WORKING_TYPE: {
        MARK_PRICE: string;
        CONTRACT_PRICE: string;
    };
};
export declare const K_LINE: {
    '1m': string;
    '3m': string;
    '5m': string;
    '15m': string;
    '30m': string;
    '1h': string;
    '2h': string;
    '4h': string;
    '6h': string;
    '8h': string;
    '12h': string;
    '1d': string;
    '3d': string;
    '1w': string;
    '1M': string;
};
export declare const SYMBOL: {
    BTCBUSD: string;
    ETHBUSD: string;
    ETHUSDT: string;
    BTCUSDT: string;
    LTCUSDT: string;
};
export declare const STRATEGY_STATUS: {
    CREATED: string;
    STARTED: string;
    FINISHED: string;
    CANCELED: string;
    HOLD: string;
    UNHOLD: string;
};
export declare const HOLD_STATUS: {
    STARTED: string;
    FINISHED: string;
    CANCELED: string;
};
export declare const DEFAULT_STRATEGY_OPTIONS: {
    RISK_PERCENT: number;
    MIN_AMOUNT_USDT: number;
};
export declare const STRATEGY_ACTION_SELL = "sell";
export declare const STRATEGY_ACTION_BUY = "buy";
export declare const BOT_STAT = "stat";
//# sourceMappingURL=constants.d.ts.map