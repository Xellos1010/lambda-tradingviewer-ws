"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const config_1 = __importDefault(require("../config"));
class Cognito {
    constructor() {
        aws_sdk_1.default.config.region = config_1.default.cognito.region;
        this._cognitoIdentityServiceProvider = null;
    }
    getCognitoIdentityServiceProvider() {
        if (!this._cognitoIdentityServiceProvider) {
            this._cognitoIdentityServiceProvider = new aws_sdk_1.default.CognitoIdentityServiceProvider({
                apiVersion: '2016-04-18'
            });
        }
        return this._cognitoIdentityServiceProvider;
    }
    async getUserByAccessToken(token) {
        const params = {
            AccessToken: token
        };
        const user = await this.getCognitoIdentityServiceProvider().getUser(params).promise();
        const userData = {
            ...user,
            ...Object.fromEntries(user.UserAttributes.map((o) => [o.Name, o.Value]))
        };
        return {
            email: userData.email,
            sub: userData.sub,
        };
    }
}
exports.default = new Cognito();
//# sourceMappingURL=cognito.js.map