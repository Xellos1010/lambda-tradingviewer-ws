"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.calculateOrderFills = exports.calculateProfit = exports.getOrderQuantity = exports.getOrderStatus = exports.getOrderPrice = void 0;
const getOrderPrice = (o) => {
    if (!o) {
        return 0;
    }
    return Number(o.avgPrice) || Number(o.price) || Number(o.stopPrice) || 0;
};
exports.getOrderPrice = getOrderPrice;
const getOrderStatus = (o) => {
    return o && o.status;
};
exports.getOrderStatus = getOrderStatus;
const getOrderQuantity = (o) => {
    if (!o) {
        return 0;
    }
    return Number(o.totalQty) || Number(o.origQty);
};
exports.getOrderQuantity = getOrderQuantity;
const calculateProfit = (buyOrder, sellOrder) => {
    if (!buyOrder || !sellOrder) {
        return 0;
    }
    const buyPrice = (0, exports.getOrderPrice)(buyOrder);
    const sellPrice = (0, exports.getOrderPrice)(sellOrder);
    const qty = (0, exports.getOrderQuantity)(buyOrder);
    return (sellPrice - buyPrice) * qty;
};
exports.calculateProfit = calculateProfit;
const calculateOrderFills = (fills = []) => {
    let totalQty = 0;
    let priceQty = 0;
    let commission = 0;
    let commissionAsset = 'USD';
    for (const f of fills) {
        commissionAsset = f.commissionAsset;
        commission += (Number(f.commission) || 0);
        priceQty += (Number(f.price) || 0) * (Number(f.qty) || 0);
        totalQty += (Number(f.qty) || 0);
    }
    return {
        commission,
        commissionAsset,
        totalQty,
        avgPrice: totalQty > 0 ? (priceQty / totalQty) : 0,
    };
};
exports.calculateOrderFills = calculateOrderFills;
//# sourceMappingURL=order.js.map