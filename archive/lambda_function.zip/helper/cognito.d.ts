import AWS from 'aws-sdk';
declare class Cognito {
    private _cognitoIdentityServiceProvider;
    constructor();
    getCognitoIdentityServiceProvider(): AWS.CognitoIdentityServiceProvider;
    getUserByAccessToken(token: string): Promise<{
        email: string;
        sub: string;
    }>;
}
declare const _default: Cognito;
export default _default;
//# sourceMappingURL=cognito.d.ts.map