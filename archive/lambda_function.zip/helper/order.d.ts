export declare const getOrderPrice: (o: TOrder | undefined) => number;
export declare const getOrderStatus: (o: TOrder) => string | undefined;
export declare const getOrderQuantity: (o: TOrder | undefined) => number;
export declare const calculateProfit: (buyOrder: TOrder | undefined, sellOrder: TOrder | undefined) => number;
export declare const calculateOrderFills: (fills?: TFill[]) => {
    commission: number;
    commissionAsset: string;
    totalQty: number;
    avgPrice: number;
};
//# sourceMappingURL=order.d.ts.map