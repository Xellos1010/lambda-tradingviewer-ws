import { APIGatewayProxyHandler } from "aws-lambda";
export declare const errorResponse: (statusCode: number, message: string) => {
    statusCode: number;
    body: string;
    headers: {
        "Content-Type": string;
        "Access-Control-Allow-Origin": string;
    };
};
export declare const successResponse: () => {
    statusCode: number;
    body: string;
    headers: {
        "Content-Type": string;
        "Access-Control-Allow-Origin": string;
        "Access-Control-Allow-Methods": string;
        "Access-Control-Allow-Headers": string;
    };
};
export declare const handler: APIGatewayProxyHandler;
//# sourceMappingURL=index.d.ts.map