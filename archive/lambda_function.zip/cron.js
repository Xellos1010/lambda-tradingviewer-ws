"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const hold_1 = __importDefault(require("./db/provider/hold"));
const strategy_1 = __importDefault(require("./db/provider/strategy"));
const BaseApiSpotService_1 = __importDefault(require("./provider/BaseApiSpotService"));
const order_1 = require("./helper/order");
const constants_1 = require("./constants");
class CheckHold {
    constructor(hold) {
        this.hold = hold;
        this.api = new BaseApiSpotService_1.default(this.hold.symbol);
    }
    async check() {
        if (this.hold.orderId) {
            await this.checkOrder();
            if ((0, order_1.getOrderStatus)(this.hold.data.sellOrder) === constants_1.ORDER.STATUS.FILLED) {
                await this.unHold();
            }
        }
    }
    async checkOrder() {
        const orderData = await this.api.checkStatus(this.hold.orderId);
        if (!this.hold.data) {
            this.hold.data = {};
        }
        if (orderData && orderData.orderId && (orderData.orderId !== this.hold.orderId || (0, order_1.getOrderStatus)(this.hold.data.sellOrder) !== String(orderData.status))) {
            this.hold.data.sellOrder = orderData;
            const { avgPrice, totalQty, commission, commissionAsset } = (0, order_1.calculateOrderFills)(orderData && orderData.fills);
            this.hold.data.sellOrder.totalQty = totalQty;
            this.hold.data.sellOrder.commission = commission;
            this.hold.data.sellOrder.avgPrice = avgPrice;
            this.hold.data.sellOrder.commissionAsset = commissionAsset;
            await hold_1.default.update(this.hold);
        }
    }
    async unHold() {
        const strategies = await strategy_1.default.getByHoldId(this.hold.type, this.hold.symbol, this.hold.id);
        if (strategies && strategies.length > 0) {
            for (const s of strategies) {
                try {
                    const qty = (0, order_1.getOrderQuantity)(s.data?.buyOrder);
                    const commission = this.hold.data.sellOrder.totalQty > 0 ? this.hold.data.sellOrder.commission * qty /
                        this.hold.data.sellOrder.totalQty : 0;
                    const sell = { ...this.hold.data.sellOrder, totalQty: qty, commission };
                    s.profit = (0, order_1.calculateProfit)(s.data?.buyOrder, sell);
                    s.data = { ...s.data, sellOrder: sell };
                    await strategy_1.default.update({ ...s, status: constants_1.STRATEGY_STATUS.UNHOLD });
                }
                catch (e) {
                    console.log('error set profit', { s, hold: this.hold });
                }
            }
        }
        this.hold.status = constants_1.HOLD_STATUS.FINISHED;
        await hold_1.default.update(this.hold);
    }
}
const handler = async () => {
    const holds = await hold_1.default.getCurrentHolds();
    for (const hold of holds) {
        try {
            const chHold = new CheckHold(hold);
            await chHold.check();
        }
        catch (e) {
            console.log('error', e);
        }
    }
    return { success: true, statusCode: 200 };
};
exports.handler = handler;
//# sourceMappingURL=cron.js.map