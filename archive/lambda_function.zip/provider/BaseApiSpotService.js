"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const coinbase_pro_node_1 = require("coinbase-pro-node");
const config_1 = __importDefault(require("../config"));
class BaseApiSpotService {
    constructor(symbol) {
        this.symbol = symbol;
        const auth = {
            apiKey: config_1.default.coinbase.key,
            apiSecret: config_1.default.coinbase.secret,
            passphrase: config_1.default.coinbase.passphrase,
            useSandbox: false,
        };
        this.client = new coinbase_pro_node_1.CoinbasePro(auth);
    }
    async getBalance(currency, workingCurrency, currentPrice) {
        const accounts = await this.client.rest.account.listAccounts();
        const account = accounts.find((acc) => acc.currency === currency);
        let onOrder = 0;
        let available = Number(account?.available || 0);
        let total = available + Number(account?.hold || 0);
        if (workingCurrency && currentPrice) {
            const workingAccount = accounts.find((acc) => acc.currency === workingCurrency);
            const workingOnOrder = Number(workingAccount?.hold || 0);
            total += currentPrice * workingOnOrder;
            onOrder = workingOnOrder;
        }
        return { total, available, onOrder };
    }
    async getPrice(symbol) {
        symbol = symbol || this.symbol;
        const ticker = await this.client.rest.product.getProductTicker(symbol);
        return Number(ticker.price);
    }
    async limitSell(quantity, price) {
        const order = {
            product_id: this.symbol,
            side: coinbase_pro_node_1.OrderSide.SELL,
            price: price.toFixed(2),
            size: quantity.toFixed(3),
            type: coinbase_pro_node_1.OrderType.LIMIT,
        };
        return this.client.rest.order.placeOrder(order);
    }
    async limitBuy(quantity, price) {
        const order = {
            product_id: this.symbol,
            side: coinbase_pro_node_1.OrderSide.BUY,
            price: price.toFixed(2),
            size: quantity.toFixed(3),
            type: coinbase_pro_node_1.OrderType.LIMIT,
        };
        return this.client.rest.order.placeOrder(order);
    }
    async marketSell(quantity) {
        const order = {
            product_id: this.symbol,
            side: coinbase_pro_node_1.OrderSide.SELL,
            type: coinbase_pro_node_1.OrderType.MARKET,
            size: quantity.toFixed(5),
        };
        return this.client.rest.order.placeOrder(order);
    }
    async marketBuy(quantity) {
        const roundedFunds = Math.floor(quantity * 100) / 100;
        const order = {
            product_id: this.symbol,
            side: coinbase_pro_node_1.OrderSide.BUY,
            type: coinbase_pro_node_1.OrderType.MARKET,
            funds: roundedFunds.toFixed(2),
        };
        return this.client.rest.order.placeOrder(order);
    }
    async checkStatus(orderId) {
        const order = await this.client.rest.order.getOrder(orderId);
        if (order === null) {
            throw new Error(`Order with ID ${orderId} not found`);
        }
        return order.status;
    }
    async cancelOrder(orderId) {
        if (!orderId) {
            return;
        }
        return this.client.rest.order.cancelOrder(orderId);
    }
}
exports.default = BaseApiSpotService;
//# sourceMappingURL=BaseApiSpotService.js.map