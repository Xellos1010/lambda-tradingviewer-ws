import { CoinbasePro } from "coinbase-pro-node";
export default class BaseApiSpotService {
    symbol: string;
    client: CoinbasePro;
    constructor(symbol: string);
    getBalance(currency: string, workingCurrency?: string, currentPrice?: number): Promise<{
        total: number;
        available: number;
        onOrder: number;
    }>;
    getPrice(symbol?: string): Promise<number>;
    limitSell(quantity: number, price: number): Promise<unknown>;
    limitBuy(quantity: number, price: number): Promise<unknown>;
    marketSell(quantity: number): Promise<unknown>;
    marketBuy(quantity: number): Promise<unknown>;
    checkStatus(orderId: string): Promise<string>;
    cancelOrder(orderId: string | undefined): Promise<unknown>;
}
//# sourceMappingURL=BaseApiSpotService.d.ts.map