"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const constants_1 = require("./constants");
const config_1 = __importDefault(require("./config"));
const strategy_1 = __importDefault(require("./db/provider/strategy"));
const SpotStrategy_1 = __importDefault(require("./strategy/SpotStrategy"));
const getAction = (action) => {
    return action;
};
const signalSpotProcessing = async (action, symbol, currency, type) => {
    try {
        const strategy = new SpotStrategy_1.default(symbol, type);
        await strategy.init();
        if (action === constants_1.STRATEGY_ACTION_SELL) {
            const lastStrategy = await strategy_1.default.getCurrentStrategy(type, symbol);
            if (lastStrategy) {
                strategy.setStrategy(lastStrategy);
            }
            if (strategy.strategy.status !== constants_1.STRATEGY_STATUS.STARTED) {
                return;
            }
            await strategy.sell();
        }
        else if (action === constants_1.STRATEGY_ACTION_BUY) {
            try {
                const lastStrategy = await strategy_1.default.getCurrentStrategy(type, symbol);
                if (lastStrategy?.id) {
                    console.log('strategy in progress. do nothing');
                    return;
                }
                await strategy.buy(currency);
            }
            catch (e) {
                console.log('error buy', e);
            }
        }
    }
    catch (e) {
        console.error('signalSpotProcessing error', e);
    }
};
const parseBody = (str) => {
    const result = {};
    let key = '';
    let value = '';
    let insideParentheses = false;
    for (let i = 0; i < str.length; i++) {
        const char = str[i];
        if (char === '(')
            insideParentheses = true;
        if (char === ')')
            insideParentheses = false;
        if (char === ',' && !insideParentheses) {
            result[key.trim()] = value.trim();
            key = '';
            value = '';
        }
        else if (char === ':' && key === '') {
            key = value;
            value = '';
        }
        else {
            value += char;
        }
    }
    if (key !== '') {
        result[key.trim()] = value.trim();
    }
    return {
        strategy_name: result.strategy_name,
        strategy_params: result.strategy_params,
        order_action: result.order_action,
        contracts: result.contracts,
        ticker: result.ticker,
        position_size: result.position_size,
    };
};
const handler = async (event) => {
    console.log("Received event:", JSON.stringify(event, null, 2));
    if (event === null) {
        console.log("Body is null");
        return '400, "Missing body"';
    }
    const bodyStr = event;
    let body = parseBody(bodyStr);
    console.log("Parsed body:", body);
    const strategyName = body.strategy_name;
    console.log("Strategy Name:", strategyName);
    const strategyParams = body.strategy_params;
    console.log("Strategy Params:", strategyParams);
    const orderAction = body.order_action;
    console.log("Order Action:", orderAction);
    const contracts = body.contracts;
    console.log("Contracts:", contracts);
    const ticker = body.ticker;
    console.log("Ticker:", ticker);
    const positionSize = body.position_size;
    console.log("Position Size:", positionSize);
    const action = getAction(orderAction);
    const asset = config_1.default.strategy.asset;
    const currency = config_1.default.strategy.currency;
    const symbol = `${asset}-${currency}`;
    const type = config_1.default.strategy.type;
    try {
        body = await signalSpotProcessing(action, symbol, currency, type);
    }
    catch (e) {
        console.log('error', e);
    }
    return 'Success';
};
exports.handler = handler;
const inputStr = "strategy_name:V2-RSI-BB-Pyramid-v5,strategy_params:(84, 12, close, 12, 200, hlc3, 3, 2, 3, 1, 8, 2023, 6, 9, 2023),order_action:buy,contracts:.005,ticker:ticker,position_size:0";
(0, exports.handler)(inputStr)
    .then((result) => {
    console.log("Handler result:", result);
})
    .catch((error) => {
    console.error("Handler error:", error);
});
//# sourceMappingURL=test-main-service.js.map