"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const BaseApiSpotService_1 = __importDefault(require("./provider/BaseApiSpotService"));
const symbol = "BTC-USD";
const spotService = new BaseApiSpotService_1.default(symbol);
(async () => {
    try {
        const balance = await spotService.getBalance("BTC");
        console.log("Balance:", balance);
        const price = await spotService.getPrice();
        console.log("Price:", price);
    }
    catch (error) {
        console.error("Error:", error);
    }
})();
//# sourceMappingURL=test-baseapi-spot-service.js.map