"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const SpotStrategyBase_1 = __importDefault(require("./SpotStrategyBase"));
const constants_1 = require("../constants");
const hold_1 = __importDefault(require("../db/provider/hold"));
const strategy_1 = __importDefault(require("../db/provider/strategy"));
const order_1 = require("../helper/order");
class SpotStrategy extends SpotStrategyBase_1.default {
    async calculatePositionQty(symbol, currency) {
        try {
            const { available: balance } = await this.getBalance(currency);
            const currentPrice = await this.getPrice(symbol);
            if (currentPrice > 0 && balance > 0) {
                let qty = balance;
                if (qty < 1)
                    throw new Error("not enough balance");
                return qty;
            }
            return 0.01;
        }
        catch (e) {
            throw new Error(e);
        }
    }
    async copyStrategy(strategy, similar) {
        strategy.status = constants_1.STRATEGY_STATUS.STARTED;
        strategy.data = {
            ...(similar.data || {}),
            fromStrategyId: similar.id,
        };
        await strategy_1.default.update(strategy);
        return strategy;
    }
    async sell() {
        const { available: balance } = await this.getBalance("BTC");
        let sellQty = balance;
        const sellOrder = (await this.marketSell(sellQty));
        const { avgPrice, totalQty, commission, commissionAsset } = (0, order_1.calculateOrderFills)(sellOrder && sellOrder.fills);
        sellOrder.avgPrice = avgPrice;
        sellOrder.totalQty = totalQty;
        sellOrder.commission = commission;
        sellOrder.commissionAsset = commissionAsset;
        this.strategy.profit = (0, order_1.calculateProfit)(this.strategy?.data?.buyOrder, sellOrder);
        this.setData({ sellOrder });
        this.strategy.status = constants_1.STRATEGY_STATUS.FINISHED;
        await strategy_1.default.update(this.strategy);
    }
    async buy(currency) {
        if (this.setting.data.isReuseHold) {
            const currentPrice = await this.getPrice();
            const similar = await strategy_1.default.getSimilarHold(this.strategy, currentPrice);
            if (similar && similar.id) {
                if (await this.removeFromHold(similar)) {
                    this.strategy = await this.copyStrategy(this.strategy, similar);
                    return;
                }
            }
        }
        const qty = await this.calculatePositionQty(this.symbol, currency);
        const buyOrder = (await this.marketBuy(qty));
        const { avgPrice, totalQty, commission, commissionAsset } = (0, order_1.calculateOrderFills)(buyOrder && buyOrder.fills);
        buyOrder.commission = commission;
        buyOrder.commissionAsset = commissionAsset;
        buyOrder.avgPrice = avgPrice;
        buyOrder.totalQty = totalQty;
        this.setData({ buyOrder });
        this.strategy.status = constants_1.STRATEGY_STATUS.STARTED;
        await strategy_1.default.update(this.strategy);
    }
    async checkOrder(hold) {
        const orderData = await this.checkStatus(hold.orderId);
        if (!hold.data) {
            hold.data = {};
        }
        if (orderData &&
            orderData.orderId &&
            (0, order_1.getOrderStatus)(hold.data.sellOrder) !== String(orderData.status)) {
            hold.data.sellOrder = orderData;
            const { avgPrice, totalQty, commission, commissionAsset } = (0, order_1.calculateOrderFills)(orderData && orderData.fills);
            hold.data.sellOrder.totalQty = totalQty;
            hold.data.sellOrder.commission = commission;
            hold.data.sellOrder.avgPrice = avgPrice;
            hold.data.sellOrder.commissionAsset = commissionAsset;
            await hold_1.default.update(hold);
        }
        return hold;
    }
    async removeFromHold(strategy) {
        const holdId = String(strategy.holdId);
        const hold = await this.checkOrder((await hold_1.default.getById(holdId)));
        if ((0, order_1.getOrderStatus)(hold.data && hold.data.sellOrder) === constants_1.ORDER.STATUS.FILLED) {
            return false;
        }
        else {
            delete strategy.holdId;
            delete strategy.unHoldPrice;
            strategy.status = constants_1.STRATEGY_STATUS.CANCELED;
            await strategy_1.default.update(strategy);
            await strategy_1.default.removeFields(strategy.id, [
                "holdId",
                "unHoldPrice",
            ]);
            const calcHold = await this.recalculateHold(hold);
            if (calcHold) {
                await this.createOrUpdateOrder(calcHold);
            }
            else {
                await this.holdCancel(hold);
                hold.status = constants_1.HOLD_STATUS.CANCELED;
                await hold_1.default.update(hold);
            }
        }
        return true;
    }
    async recalculateHold(hold) {
        const list = await strategy_1.default.getByHoldId(hold.type, hold.symbol, hold.id);
        if (list.length === 0) {
            return undefined;
        }
        const data = {
            strategies: [],
            priceQty: [],
            ids: [],
        };
        for (const s of list) {
            const price = (0, order_1.getOrderPrice)(s.data?.buyOrder);
            const qty = (0, order_1.getOrderQuantity)(s.data?.buyOrder);
            if (price > 0 && qty > 0) {
                data.priceQty.push({ price, qty });
                data.ids.push(s.id);
                data.strategies.push(s);
            }
        }
        let qty = 0;
        let priceQty = 0;
        for (const s of data.priceQty) {
            priceQty += (Number(s.price) || 0) * (Number(s.qty) || 0);
            qty += Number(s.qty) || 0;
        }
        hold.avgPrice = qty > 0 ? priceQty / qty : 0;
        hold.avgPriceProfit = hold.avgPrice * 1.01;
        hold.qty = qty;
        await hold_1.default.update(hold);
        if (list && list.length > 0) {
            const prs = [];
            for (const s of list) {
                prs.push(strategy_1.default.update({ ...s, unHoldPrice: hold.avgPriceProfit }));
            }
            await Promise.all(prs);
        }
        return hold;
    }
    async holdCancel(hold) {
        try {
            await this.cancelOrder(hold.orderId);
            await hold_1.default.removeFields(hold.id, ["orderId"]);
        }
        catch (e) {
            console.log("cancel order error", e);
        }
    }
    async createOrUpdateOrder(hold) {
        if (hold.orderId) {
            await this.holdCancel(hold);
        }
        if (hold?.qty &&
            hold?.avgPriceProfit &&
            hold?.qty > 0 &&
            hold?.avgPriceProfit > 0) {
            const order = (await this.limitSell(hold.qty, hold.avgPriceProfit));
            hold.orderId = String(order.orderId);
            await hold_1.default.update(hold);
        }
    }
    async addToHold() {
        let hold = await hold_1.default.getByTypeAndSymbolStatus(this.type, this.symbol, constants_1.HOLD_STATUS.STARTED);
        if (!hold) {
            hold = await hold_1.default.create({
                type: this.type,
                symbol: this.symbol,
                status: constants_1.HOLD_STATUS.STARTED,
            });
        }
        this.strategy.holdId = hold.id;
        this.strategy.status = constants_1.STRATEGY_STATUS.HOLD;
        await strategy_1.default.update(this.strategy);
        const calcHold = await this.recalculateHold(hold);
        if (calcHold) {
            await this.createOrUpdateOrder(calcHold);
        }
    }
    async stat() {
        const type = this.setting.type;
        const symbol = this.setting.symbol;
        const prs = [];
        prs.push(hold_1.default.getFirst({ type, symbol, status: constants_1.HOLD_STATUS.STARTED }));
        prs.push(strategy_1.default.count({ type, symbol, status: constants_1.STRATEGY_STATUS.HOLD }));
        prs.push(strategy_1.default.getList({ type, symbol }, { order: "descending" }));
        prs.push(strategy_1.default.calculateProfit(type, symbol));
        const [hold, holdCount, items, profit] = await Promise.all(prs);
        if (typeof hold === "object" && hold !== null && "avgPriceProfit" in hold) {
            if (items && Array.isArray(items)) {
                items.sort((i1, i2) => (i1.createdAt > i2.createdAt ? -1 : 1));
            }
            return {
                holds: {
                    [type]: {
                        avgPrice: hold.avgPriceProfit,
                        qty: hold.qty,
                        cnt: holdCount,
                        qtyUSDT: (Number(hold.qty) || 0) * (Number(hold.avgPriceProfit) || 0),
                        symbol: hold.symbol,
                    },
                },
                profits: { [type]: profit },
                types: [type],
                items: items,
            };
        }
        console.log("Undefined being returned for stat");
        return undefined;
    }
}
exports.default = SpotStrategy;
//# sourceMappingURL=SpotStrategy.js.map