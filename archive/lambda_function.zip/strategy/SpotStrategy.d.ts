import SpotStrategyBase from "./SpotStrategyBase";
declare class SpotStrategy extends SpotStrategyBase {
    calculatePositionQty(symbol: string, currency: string): Promise<number>;
    copyStrategy(strategy: TStrategy, similar: TStrategy): Promise<TStrategy>;
    sell(): Promise<void>;
    buy(currency: string): Promise<void>;
    checkOrder(hold: THold): Promise<THold>;
    removeFromHold(strategy: TStrategy): Promise<boolean>;
    recalculateHold(hold: THold): Promise<THold | undefined>;
    holdCancel(hold: THold): Promise<void>;
    createOrUpdateOrder(hold: THold): Promise<void>;
    addToHold(): Promise<void>;
    stat(): Promise<{
        holds: {
            [x: string]: {
                avgPrice: number | undefined;
                qty: number | undefined;
                cnt: number | THold | TStrategy[] | undefined;
                qtyUSDT: number;
                symbol: string;
            };
        };
        profits: {
            [x: string]: number | THold | TStrategy[] | undefined;
        };
        types: string[];
        items: number | THold | TStrategy[] | undefined;
    } | undefined>;
}
export default SpotStrategy;
//# sourceMappingURL=SpotStrategy.d.ts.map