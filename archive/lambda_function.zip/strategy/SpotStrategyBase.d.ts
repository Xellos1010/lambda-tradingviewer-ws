import BaseApiSpotService from '../provider/BaseApiSpotService';
declare class SpotStrategyBase extends BaseApiSpotService {
    type: string;
    strategy: TStrategy;
    setting: TSetting;
    constructor(symbol: string, type: string);
    setStrategy(s: TStrategy): void;
    setData(data: any): void;
    init(): Promise<void>;
}
export default SpotStrategyBase;
//# sourceMappingURL=SpotStrategyBase.d.ts.map