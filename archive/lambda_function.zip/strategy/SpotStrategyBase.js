"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const BaseApiSpotService_1 = __importDefault(require("../provider/BaseApiSpotService"));
const setting_1 = __importDefault(require("../db/provider/setting"));
const constants_1 = require("../constants");
const config_1 = __importDefault(require("../config"));
class SpotStrategyBase extends BaseApiSpotService_1.default {
    constructor(symbol, type) {
        super(symbol);
        this.type = type;
        this.symbol = symbol;
        this.strategy = {
            status: constants_1.STRATEGY_STATUS.CREATED,
            type,
            symbol,
            data: {}
        };
        this.setting = {
            type,
            symbol,
            data: config_1.default.strategy.defaultSetting
        };
    }
    setStrategy(s) {
        this.strategy = s;
    }
    setData(data) {
        this.strategy.data = { ...(this.strategy.data || {}), ...data };
    }
    async init() {
        this.setting = await setting_1.default.getByTypeAndSymbol(this.type, this.symbol);
    }
}
exports.default = SpotStrategyBase;
//# sourceMappingURL=SpotStrategyBase.js.map